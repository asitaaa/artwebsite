module.exports=[31009,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_artwork_%5Bslug%5D_page_actions_0b2b471d.js.map