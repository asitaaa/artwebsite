module.exports=[41932,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_awards_page_actions_529f05b3.js.map