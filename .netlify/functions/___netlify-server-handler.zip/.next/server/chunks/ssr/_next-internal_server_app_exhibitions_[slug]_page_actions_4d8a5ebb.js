module.exports=[50248,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_exhibitions_%5Bslug%5D_page_actions_4d8a5ebb.js.map