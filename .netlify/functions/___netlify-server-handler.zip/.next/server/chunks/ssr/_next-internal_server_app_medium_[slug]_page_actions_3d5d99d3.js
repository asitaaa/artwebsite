module.exports=[10443,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_medium_%5Bslug%5D_page_actions_3d5d99d3.js.map